package com.yilena.service.config;

import org.springframework.beans.factory.annotation.Value;
import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RestClientConfig {

    @Bean
    public RestHighLevelClient restHighLevelClient(@Value("${elasticSearch.host}") String host) {
        return new RestHighLevelClient(RestClient.builder(
                // todo 这里再git里要进行更改
                HttpHost.create("http://192.168.100.128:9200")
        ));
    }
}
